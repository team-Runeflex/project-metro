using UnityEngine;

public class SkillProjectile : MonoBehaviour
{
    public Skill skill; // ScriptableObject로 정의한 Skill

    private void OnTriggerEnter(Collider other)
    {
        // 충돌한 대상이 적일 때 효과 적용
        if (other.CompareTag("Enemy"))
        {
            EnemyState targetHealth = other.GetComponent<EnemyState>();
            if (targetHealth != null)
            {
                skill.SkillAction(this.gameObject, other.gameObject);
            }
            
            // 프로젝트타일을 파괴 또는 풀링 시스템으로 반환
            Destroy(gameObject); // 풀링을 사용 중이면 이 부분을 풀링 코드로 변경
        }
    }
}
﻿using UnityEngine;

[CreateAssetMenu(menuName = "SkillEffects/DamageEffect")]
public class DamageEffect : ScriptableObject, ISkillEffect
{
    public float damage;

    public void Apply(GameObject user, GameObject target)
    { 
        EnemyState targetHealth = target.GetComponent<EnemyState>();
        if (targetHealth != null)
        {
            targetHealth.TakeDamage(damage);
        }
    }
}
﻿using UnityEngine;

[CreateAssetMenu(menuName = "SkillEffects/ExplosionEffect")]
public class ExplosionEffect : ScriptableObject, ISkillEffect
{
    public float damage;
    public float explosionRadius;
    
    public void Apply(GameObject user, GameObject target = null)
    {
        SkillEffect.SkillUsed += OnSkillUsed;

    }

    private void OnSkillUsed(GameObject user, GameObject target)
    {
        // 폭발 로직
        
        if(target.CompareTag("Enemy")){
            target.GetComponent<EnemyState>().TakeDamage(damage);
            Collider2D[] colls = Physics2D.OverlapCircleAll(target.transform.position, explosionRadius);
        }
    }
}
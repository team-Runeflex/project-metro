using UnityEngine;

public enum SkillType
{
    Offensive,
    Defensive,
    Heal,
    Passive,
    Movement
}


public abstract class Skill : ScriptableObject
{
    [SerializeField]
    private string skillName;
    public string SkillName { get => skillName; set => skillName = value; }
    [SerializeField]
    private Sprite icon;
    public Sprite Icon { get => icon; set => icon = value; }
    [SerializeField]
    private float cooldown;
    public float Cooldown { get => cooldown; set => cooldown = value; }

    private float cooldownTimer;
    private bool cooldownActive;
    
    [SerializeField]
    private SkillType skillType;
    public SkillType SkillType { get => skillType; set => skillType = value; }
    
    // 외부에서 호출하는 메서드
    public void UseSkill(GameObject user, GameObject target)
    {
        // 공통 로직 (예: 쿨다운 처리)
        HandleCooldown();

        // 실제 스킬 동작
        SkillAction(user, target);
    }
    
    public abstract void SkillAction(GameObject user, GameObject target = null);
    private void HandleCooldown()
    {
        // 쿨다운 처리 로직
        cooldownTimer -= Time.deltaTime;
        if (cooldownTimer <= 0)
        {
            cooldownTimer = 0;
            cooldownActive = true;
        }
    }

}

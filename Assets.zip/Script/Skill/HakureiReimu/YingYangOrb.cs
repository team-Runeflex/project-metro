using UnityEngine;

[CreateAssetMenu(menuName = "ScriptableObject/Skill/Ying Yang Orb")]
public class YinYangOrb : ProjectileSkill
{
    public float damage;
    public Sprite image; 


    public override void SkillAction(GameObject user, GameObject target = null)
    {
        Debug.Log("YinYangOrb");
    }
}